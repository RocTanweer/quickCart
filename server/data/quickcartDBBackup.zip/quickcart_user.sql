-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: localhost    Database: quickcart
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `user_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `profile_image` varchar(255) NOT NULL,
  `role` enum('USER','ADMIN') NOT NULL DEFAULT 'USER',
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `email_UNIQUE` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'Roc Tanweer','roc@admin.com','$2b$10$c8HKw1IpjR0oqZXwpCoUhe5R.LByeNQJCe3xaj.2Aic1ypObIcV1C','https://google.com','ADMIN'),(48,'John Smith','john.smith@example.com','$2b$10$ELb0vmy5zkqEPjn7q2upf.Ga.q.aMf2pETHn2rVTzc57JjzykmZeu','https://google.com','USER'),(49,'Jane Doe','jane.doe@example.com','$2b$10$Ep03DIJ/cr1JajkNR3MwN.dnqX8ybQ2Vkx7q2He.255oUED4KSI/S','https://google.com','USER'),(50,'Emily Davis','emily.davis@example.com','$2b$10$lsXrNVia0vchK8fqoPg5betR6M6tY5ZGA0FCw8EN0ayEDhCaYd4Ry','https://google.com','USER'),(51,'Jessica Garcia','jessica.garcia@example.com','$2b$10$kDC7k7iqnHoMPL6ikAtesOxIodyhIj21SQ4G1V8nOuyFzlm3qBRta','https://google.com','USER'),(52,'David Brown','david.brown@example.com','$2b$10$6umarFRZmY4sKuBt0kdG0OqGq8bRghWe5x5xo7Hd2m0oWfJA/NW3a','https://google.com','USER'),(53,'James Miller','james.miller@example.com','$2b$10$uG95ycH.p.k6mQKJSiU7BOL1Z.3TKF.kOmhpvx9XvuP8sJieNIePy','https://google.com','USER'),(54,'Daniel Martinez','daniel.martinez@example.com','$2b$10$bD52qAIL.79rJaKGKFMYwOGfMws/LOy7q2Sa/d6aZo6gFOjEZIdAW','https://google.com','USER');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-05-28 14:49:46
